package arackiralama;
/**
 *  MEHMET TURAN 02210224055
 *  DOĞAÇ GÜLAÇAN 02210224057
 */
/**
 *
 * @author Mehmet turan
 */
public class Main {
    
    public static void main(String[] args) {
        KullaniciGiris k=new KullaniciGiris();

    }
}

package arackiralama;
/**
 *  MEHMET TURAN 02210224055
 *  DOĞAÇ GÜLAÇAN 02210224057
 */
/**
 *
 * @author Mehmet turan
 */
public interface Iucrethesapla {
    void ucrethesapla();
}
